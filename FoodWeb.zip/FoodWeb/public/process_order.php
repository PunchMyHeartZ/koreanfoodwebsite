<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Allow CORS for development
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    // Log incoming request
    $request_log = [
        'time' => date('Y-m-d H:i:s'),
        'method' => $_SERVER['REQUEST_METHOD'],
        'raw_input' => file_get_contents('php://input')
    ];
    
    // Create or append to order_debug.log
    file_put_contents('order_debug.log', json_encode($request_log) . "\n", FILE_APPEND);

    // Get POST data
    $json_data = file_get_contents('php://input');
    $order_data = json_decode($json_data, true);

    // Check for JSON decoding errors
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON: ' . json_last_error_msg());
    }

    // Validate order data
    if (empty($order_data['customerName']) || empty($order_data['orderItems'])) {
        throw new Exception('Missing required order fields (customerName, orderItems).');
    }

    // Log the order data
    file_put_contents('orders.log', json_encode($order_data) . "\n", FILE_APPEND);

    // Process the order (for example, saving to a database or sending a confirmation)
    // Here, we'll simulate processing with a success message
    // In a real-world scenario, you would add database interactions or other business logic

    // Send success response
    echo json_encode([
        'success' => true,
        'message' => 'Order processed successfully',
        'data' => $order_data
    ]);

} catch (Exception $e) {
    // Log the error
    file_put_contents('error.log', date('Y-m-d H:i:s') . ': ' . $e->getMessage() . "\n", FILE_APPEND);

    // Send error response
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error processing order: ' . $e->getMessage()
    ]);
}
?>
