// app.js
const express = require('express');
const { mysqlConnection, pgClient, mongoClient } = require('./db');

const app = express();
const port = 3000;

// Example route using MySQL
app.get('/mysql-users', (req, res) => {
    mysqlConnection.query('SELECT * FROM users', (err, results) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.json(results);
    });
});

// Example route using PostgreSQL
app.get('/pg-users', (req, res) => {
    pgClient.query('SELECT * FROM users', (err, result) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.json(result.rows);
    });
});

// Example route using MongoDB
app.get('/mongo-users', (req, res) => {
    const db = mongoClient.db('my_database');
    const collection = db.collection('users');
    
    collection.find({}).toArray((err, docs) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.json(docs);
    });
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
