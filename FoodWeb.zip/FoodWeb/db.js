// db.js
require('dotenv').config();  // Load environment variables from .env file

const mysql = require('mysql2');
const { Client } = require('pg');
const { MongoClient } = require('mongodb');

// MySQL Configuration
const mysqlConnection = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

mysqlConnection.connect((err) => {
    if (err) {
        console.error('MySQL Connection Error:', err);
    } else {
        console.log('Connected to MySQL!');
    }
});

// PostgreSQL Configuration
const pgClient = new Client({
    host: process.env.PG_HOST,
    user: process.env.PG_USER,
    password: process.env.PG_PASSWORD,
    database: process.env.PG_DATABASE,
    port: 5432  // Default PostgreSQL port
});

pgClient.connect((err) => {
    if (err) {
        console.error('PostgreSQL Connection Error:', err);
    } else {
        console.log('Connected to PostgreSQL!');
    }
});

// MongoDB Configuration
const mongoClient = new MongoClient(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

mongoClient.connect((err) => {
    if (err) {
        console.error('MongoDB Connection Error:', err);
    } else {
        console.log('Connected to MongoDB!');
    }
});

module.exports = {
    mysqlConnection,
    pgClient,
    mongoClient
};
