const express = require('express'); 
const mysql = require('mysql');
const bodyParser = require('body-parser');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const app = express();

app.use(bodyParser.json());

// SQL connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'mysql_nodejs'
});

// Connect to the database
connection.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to the MySQL database.');
});

// Middleware to serve static files and parse incoming requests
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Ensure the uploaded_slips directory exists
const uploadDir = path.join(__dirname, 'uploaded_slips');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

// Configure multer to save files to the uploaded_slips directory
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploaded_slips');
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + '-' + file.originalname);
    }
});

const upload = multer({ storage: storage });

// Root route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Serve the manage users page
app.get('/manage-users', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'manage-users.html'));
});

// Handle user registration
app.post('/register', (req, res) => {
    const { username, email, password } = req.body;

    const checkUserSql = 'SELECT * FROM users WHERE username = ? OR email = ?';
    connection.query(checkUserSql, [username, email], (error, results) => {
        if (error) {
            return res.status(500).json({ success: false, message: 'Error checking user: ' + error.message });
        }
        if (results.length > 0) {
            return res.status(400).json({ 
                success: false, 
                message: results[0].username === username ? 'Username already exists.' : 'Email already exists.'
            });
        }

        const sql = 'INSERT INTO users (username, password, email) VALUES (?, ?, ?)';
        connection.query(sql, [username, password, email], (error, results) => {
            if (error) {
                return res.status(500).json({ success: false, message: 'Error registering user: ' + error.message });
            }
            res.json({ success: true, message: 'User registered successfully!' });
        });
    });
});

// Handle user login
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    const sql = 'SELECT id, username, email FROM users WHERE username = ? AND password = ?';
    connection.query(sql, [username, password], (error, results) => {
        if (error) {
            return res.status(500).json({ success: false, message: 'Error logging in: ' + error.message });
        }
        if (results.length > 0) {
            res.json({ 
                success: true, 
                message: 'Login successful!',
                user: results[0]
            });
        } else {
            res.status(401).json({ success: false, message: 'Invalid username or password.' });
        }
    });
});

// Get all users with their roles
app.get('/api/users', (req, res) => {
    const query = 'SELECT id, username, email, role FROM users';
    connection.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Error fetching users: ' + err.message });
        }
        res.json(results);
    });
});

// Update user role
app.put('/api/users/:id/role', (req, res) => {
    const userId = req.params.id;
    const { role } = req.body;

    const validRoles = ['employee', 'manager', 'owner'];
    if (!validRoles.includes(role)) {
        return res.status(400).json({ 
            success: false, 
            message: 'Invalid role specified' 
        });
    }

    const query = 'UPDATE users SET role = ? WHERE id = ?';
    connection.query(query, [role, userId], (err, result) => {
        if (err) {
            return res.status(500).json({ 
                success: false, 
                message: 'Error updating role: ' + err.message 
            });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ 
                success: false, 
                message: 'User not found.' 
            });
        }
        res.json({ 
            success: true, 
            message: 'User role updated successfully!' 
        });
    });
});

// Handle order processing
app.post('/process_order', (req, res) => {
    const { customerName, orderItems, totalAmount } = req.body;

    if (!customerName || !orderItems || !totalAmount) {
        return res.status(400).json({ success: false, message: 'Invalid order data.' });
    }

    const orderItemsJson = JSON.stringify(orderItems);
    const sql = 'INSERT INTO orders (customer_name, order_items, total_amount) VALUES (?, ?, ?)';

    connection.query(sql, [customerName, orderItemsJson, totalAmount], (err, results) => {
        if (err) {
            console.error('Error saving order: ', err);
            return res.status(500).json({ success: false, message: 'Error saving order.' });
        }
        res.json({ success: true });
    });
});

// Retrieve all orders for the admin page
app.get('/api/orders', (req, res) => {
    const query = 'SELECT * FROM orders';
    connection.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Error fetching orders: ' + err.message });
        }
        res.json(results);
    });
});

// Serve the admin page
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Handle payment slip upload
app.post('/upload-slip', upload.single('paymentSlip'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ success: false, message: 'No file uploaded.' });
    }
    res.status(200).json({ success: true, message: 'File uploaded successfully.' });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
